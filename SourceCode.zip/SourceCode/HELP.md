# Read Me First
The following was discovered as part of building this project:

## R&D for E-Commerce Project

- Create a Basic E-Commerce Application (Admin & Client)
- Customer can make order from Web and Messaging platform (LINE, FB Messanger)
- User will be received the promotional offer in Email and Messaging platform

## Technologies

- BE: Java, Spring Boot
- DB: MySQL
- FE: HTML, CSS, JavaScript and React
- Cloud: AWS SES, S3, CloudFront and etc.
- ChatBot Platform: LINE and Messanger