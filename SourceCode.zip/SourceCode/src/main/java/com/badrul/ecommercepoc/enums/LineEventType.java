package com.badrul.ecommercepoc.enums;

public enum LineEventType {
    POSTBACK,
    MESSAGE
}
