package com.badrul.ecommercepoc.enums;

public enum UserFrom {
    WEB,
    LINE
}
