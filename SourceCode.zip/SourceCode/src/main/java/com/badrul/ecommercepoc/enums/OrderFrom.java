package com.badrul.ecommercepoc.enums;

public enum OrderFrom {
    WEB,
    LINE
}
