package com.badrul.ecommercepoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommercePocApplicationTests {

	@Test
	void contextLoads() {
	}

}
